<?php

// Bài 1: Xuất chuỗi
echo "Hello <br>";
echo ("Hello <br>");
echo "Hello World <br>";
echo "Hello","World";
echo "<br>";
// Bài 2: Xuất biến
$str = "hello string";
$x = 200;
$y = 44.6;
echo "string is: $str <br/>";
echo "integer is: $x <br/>";
echo "float is: $y <br/>";
// Bài 3: Xuất chuỗi và biến
$color = "red";
echo "My car is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>";
echo "My boat is " . $coLOR . "<br>";


?>
