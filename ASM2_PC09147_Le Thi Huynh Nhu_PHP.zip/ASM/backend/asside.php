<!-- <div class="container-fluid"> -->
<div class="row m-0">
    <aside class="col-2 p-0">
        <div id="sidebarMenu" class="col-12 bg-dark sidebar text-white h-100">
            <div class="position-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="dashboard.php">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="page.php">
                            <i class="fas fa-file-alt"></i>
                            <span>Page</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#">
                            <!-- <i class="fas fa-sitemap"></i> -->
                            <span>Quản lý Danh mục</span>
                        </a>
                        <ul class="nav flex-column sub-menu">
                            <li class="nav-item ">
                                <a class="nav-link text-white" href="index.php?page=danhmuc_upload">
                                    <span>
                                        Danh mục sản phẩm

                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="index.php?page=sanpham_upload">
                                    <span>Sản phẩm</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- </div> -->
    </aside>




    <!-- </div> -->
    <!-- </div> -->