<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <?php
    //VD1: dung the tieu de h1..h6 hien thi hello world 

    //VD2: dùng foreach hiển thị danh sách các phần tử trong mảng a là danh sách MSSV 

    ?>
</body>
</html>